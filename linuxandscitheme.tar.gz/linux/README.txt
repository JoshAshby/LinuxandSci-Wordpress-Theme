Please edit the css and check all the pages to make sure it has your code and that the links are correct, no images come with this theme, if you would like the ones used on my site (joshashby.com) please email me at joshuaashby@joshashby.com.
other wise, enjoy and besure to read my wordpress plugin and theme post: http://josh.byethost16.com/blog/2009/08/wordpress-and-stuff/
Josh
