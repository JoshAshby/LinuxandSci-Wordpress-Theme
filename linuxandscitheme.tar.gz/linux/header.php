
<p>
<html>
<head>
<?php wp_head(); ?>
<link rel="alternate" type="application/rss+xml" title="Linux and Sci RSS" href="http://josh.byethost16.com/rss.xml" />
<script>
var url_before = "http://josh.byethost16.com/Resources/Headers/header";
var url_after = ".jpg";
var min = 1;
var max = 8;
function printRndImg() {
document.write('<img src="' + url_before + ( min + Math.round(Math.random()*(max-min)) ) + url_after + '" boorder="0">')
}
</script>
  <link rel="stylesheet" type="text/css"
 href="http://josh.byethost16.com/blog/wp-content/themes/linux/style.css">
  <meta content="text/html; charset=ISO-8859-1"
 http-equiv="content-type">
  <title>Linux and Sci</title>
</head>
<body>
<table border="0" cellpadding="0" cellspacing="0" width="800" align="center">
<TR>
<TD>
<div id="top">
<a href="/blog/feed/"><img src="http://josh.byethost16.com/Resources/rss.png" height="25" width="25">Subscribe to my feed.</a> Linux and Sci - <a href="http://joshashby.com">joshashby.com</a>
</div>
</TD>
</TR>
</table>
<script>printRndImg();</script><br>
<table cellpadding="0" cellspacing="0" border="0" width="800" align="center"><TR><TD>
<ul class="solidblockmenu">
<li><a href="http://josh.byethost16.com/index.php"><span>Home</span></a></li>
<li><a href="http://josh.byethost16.com/links.php"><span>Links</span></a></li>
<li><a href="http://josh.byethost16.com/blog/category/howto/"><span>How To</span></a></li>
<li><a href="http://josh.byethost16.com/forums.php"><span>Forums</span></a></li>
<li><a href="http://josh.byethost16.com/downloads.php"><span>Downloads</span></a></li>
<li><a href="http://josh.byethost16.com/gallery.php"><span>Gallery</span></a></li>
<li><a href="http://josh.byethost16.com/contact.php"><span>Contact Me</span></a></li>
</ul>
</div>
</TD></TR></table>