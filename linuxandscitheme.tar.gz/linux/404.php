<?php
/**
 * @package WordPress
 * @subpackage linux
 */

get_header();
?>
<table cellpadding="0" cellspacing="0" border="0" width="800" align="center">
<tr>
<td>
<div id="content"
		<h2Error 404 - Not Found</h2>
</div>
</td></tr></table>
<?php get_footer(); ?>