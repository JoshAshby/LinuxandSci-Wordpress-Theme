<table border="0" align="center" width="800" cellpadding="0" cellspacing="0">
<TR>
<TD>
<div id="bottom">
<a href="http://josh.byethost16.com/index.php">Home</a> | <a href="http://josh.byethost16.com/links.php">Links</a> | <a href="http://josh.byethost16.com/blog/category/howto/">How To</a> | <a href="http://josh.byethost16.com/forums.php">Forums</a> | <a href="http://josh.byethost16.com/downloads.php">Downloads</a> | <a href="http://josh.byethost16.com/contact.php">Contact Me</a>
<br>
<a href="mailto:joshuaashby@comcast.net">2009 Josh Ashby - joshashby.com</a>
</div>
</TD>
</TR>
</table>
</p>
<?php wp_footer(); ?>